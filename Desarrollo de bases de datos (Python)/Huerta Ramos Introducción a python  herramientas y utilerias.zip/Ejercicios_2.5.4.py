#1) presenta su nombre, edad, altura en metros, en la pantalla, un dato por línea.
print ("Mi nombre es Fernando Huerta Ramos")
print ("Tengo 20 años")
print ("Mi altura es",1.74,"Metros")

#2) presenta su nombre, edad, altura en metros, en la pantalla un dato por línea,
#de manera que cada línea empieza con el símbolo gato y un espacio: #
print ("# Mi nombre es Fernando Huerta Ramos")
print ("# Tengo 20 años")
print ("# Mi altura es",1.74,"Metros")

# 3) presenta su nombre, edad, altura en metros, todos en una misma línea.
nombre = "Fernando Huerta Ramos"
estatura = 1.74
edad = 20

print ("Mi nombre es Fernando, tengo 20 años, y mido 1.74 metros")



 