# 1) asigna su primer nombre a la variable mi_nombre e imprime su nombre usando la variable.
mi_nombre = "Fernando Huerta Ramos"
edad = 20

print (mi_nombre)
print (edad)

