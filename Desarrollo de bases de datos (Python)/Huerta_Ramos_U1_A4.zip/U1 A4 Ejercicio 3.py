print(format(98765, '+09,d'))
print(format(98765, '?=9d'))
print(format(98765, '=+9d'))
print(format(98765, '09d'))