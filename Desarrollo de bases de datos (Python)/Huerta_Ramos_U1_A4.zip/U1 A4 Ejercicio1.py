print(float(3.456))
print(format(3.456, "e"))



 