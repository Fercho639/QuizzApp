print("|", format("23400.00",'>12s'), "|", sep="")
print("|", format("876.00",'>12s'), "|", sep="")
print("|", format("1230.00",'>12s'), "|", sep="")